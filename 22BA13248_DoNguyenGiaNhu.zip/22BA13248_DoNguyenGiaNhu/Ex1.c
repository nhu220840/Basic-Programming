#include <stdio.h>

int main(){
    printf("This\'s our C programming course\n");
    printf("Welcome to the first tutorial class");
}