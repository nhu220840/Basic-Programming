#include <stdio.h>
#include <math.h>

int main(){
    int x; scanf("%d", &x);
    int res = 1 * pow(x, 2) + 2 * x + 1;
    printf("%d", res);
}