#include <stdio.h>
#include "GCD.h"

int main(){
    int a, b; scanf("%d %d", &a, &b);
    printf("%d", gcd(a, b));    
}